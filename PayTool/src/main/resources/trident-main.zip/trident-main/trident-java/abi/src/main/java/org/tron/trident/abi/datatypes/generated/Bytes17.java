package org.tron.trident.abi.datatypes.generated;

import org.tron.trident.abi.datatypes.Bytes;

/**
 * Auto generated code.
 * <p><strong>Do not modifiy!</strong>
 * <p>Please use org.tron.trident.codegen.AbiTypesGenerator in the
 * <a href="https://github.com/web3j/web3j/tree/master/codegen">codegen module</a> to update.
 */
public class Bytes17 extends Bytes {
    public static final Bytes17 DEFAULT = new Bytes17(new byte[17]);

    public Bytes17(byte[] value) {
        super(17, value);
    }
}
