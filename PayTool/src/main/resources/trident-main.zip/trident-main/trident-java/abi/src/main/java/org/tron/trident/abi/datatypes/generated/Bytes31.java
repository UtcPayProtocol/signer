package org.tron.trident.abi.datatypes.generated;

import org.tron.trident.abi.datatypes.Bytes;

/**
 * Auto generated code.
 * <p><strong>Do not modifiy!</strong>
 * <p>Please use org.tron.trident.codegen.AbiTypesGenerator in the
 * <a href="https://github.com/web3j/web3j/tree/master/codegen">codegen module</a> to update.
 */
public class Bytes31 extends Bytes {
    public static final Bytes31 DEFAULT = new Bytes31(new byte[31]);

    public Bytes31(byte[] value) {
        super(31, value);
    }
}
