package org.tron.trident.abi.datatypes.generated;

import org.tron.trident.abi.datatypes.Bytes;

/**
 * Auto generated code.
 * <p><strong>Do not modifiy!</strong>
 * <p>Please use org.tron.trident.codegen.AbiTypesGenerator in the
 * <a href="https://github.com/web3j/web3j/tree/master/codegen">codegen module</a> to update.
 */
public class Bytes27 extends Bytes {
    public static final Bytes27 DEFAULT = new Bytes27(new byte[27]);

    public Bytes27(byte[] value) {
        super(27, value);
    }
}
