package org.tron.trident.core.exceptions;

public class ContractCreateException extends Exception {
    
    public ContractCreateException(String message) {
        super(message);
    }
}
